# myKAPA working AI backend (Cloudflare Workers)

This package includes the web app and a **real** AI vision endpoint at `/api/analyze-look`. It is not deployed yet. You must configure your own OpenAI API key on Cloudflare before real photo analysis will work.

## Deploy

1. Install Node.js 20+ on a computer or use a GitHub/Cloudflare build environment.
2. In this folder run `npm install` and `npx wrangler login`.
3. Run `npx wrangler secret put OPENAI_API_KEY` and paste your OpenAI API key into the private prompt. **Never put it in the HTML or a public repository.**
4. Run `npm run deploy`. Wrangler prints the Worker URL.
5. In Cloudflare Workers & Pages, open the Worker > Settings > Domains & Routes > Add Custom Domain, and set `mykapa.net` after confirming you own the domain and its DNS is on Cloudflare.
6. Test `https://<worker-url>/api/health` (should return `aiConfigured:true`) then take a photo and tap **Analyze Head to Toe**.

### Notes
- Uses OpenAI `gpt-4o-mini` vision through the Chat Completions API. An OpenAI API account with billing/credits is required.
- Images are sent to OpenAI for processing; they are not intentionally persisted by this Worker. Provider retention is governed by the provider's policies.
- For a public launch, add authentication, per-user quotas, rate limiting/WAF, abuse protections, logging without image content, an appropriate privacy policy and consent records. Otherwise unauthorized visitors can consume your API credits.
- No actual nearby business lookup is connected. The AI recommends only *types* of professionals.
- JPEG, PNG, WebP, GIF up to 10 MB. Some iPhone HEIC photos must be converted to JPEG first.
- The current front end uses local browser storage for wardrobe and profile, not shared cloud accounts.
- No beauty rating or medical diagnosis is provided.
