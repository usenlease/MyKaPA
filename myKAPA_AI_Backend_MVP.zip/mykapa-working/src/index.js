const HEADERS = { 'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff' };
const json = (value,status=200)=>new Response(JSON.stringify(value),{status,headers:HEADERS});
const allowedOrigins = (origin, requestUrl, env) => !origin || origin === new URL(requestUrl).origin || (env.ALLOWED_ORIGIN && origin === env.ALLOWED_ORIGIN);
const SYSTEM = `You are myKAPA, a respectful personal beauty, grooming and fashion assistant. Analyze ONLY what is actually visible in the provided image. Return JSON matching the requested schema. Consider hair styling, face and makeup presentation, visible skin appearance (cosmetic only), grooming, upper clothing, lower clothing, accessories, footwear and overall coordination. For every area that is not visible, state "Not visible in this photo" and suggest "No assessment possible"; do not guess. Offer practical, optional, specific suggestions only where the image provides evidence. If no improvement is necessary, say so. Do not judge beauty, attractiveness, gender identity, age, ethnicity, weight, health status or character. Do not diagnose skin conditions, injuries, or medical problems; when a user has a health concern, suggest a qualified clinician. Don't claim to detect skin disease from photos. Suggest relevant professional types only when appropriate, not invented local providers. Avoid shopping pressure. Each observation <= 180 characters and suggestion <= 220 characters. All output in English.`;
const areas=['hair','face and makeup','skin appearance','grooming','upper clothing','lower clothing','accessories','footwear','overall coordination'];
export default {
 async fetch(request,env){
  const url=new URL(request.url);
  if(url.pathname==='/api/health' && request.method==='GET')return json({ok:true,aiConfigured:!!env.OPENAI_API_KEY});
  if(url.pathname==='/api/analyze-look'){
   if(request.method!=='POST')return json({error:'Method not allowed'},405);
   if(!allowedOrigins(request.headers.get('Origin'),request.url,env))return json({error:'Origin not allowed'},403);
   if(!env.OPENAI_API_KEY)return json({error:'AI service is not configured. Add OPENAI_API_KEY as a Cloudflare Worker secret.'},503);
   const len=Number(request.headers.get('Content-Length')||0);
   if(len>11*1024*1024)return json({error:'Image too large (10 MB maximum)'},413);
   let form;
   try{form=await request.formData()}catch{return json({error:'Invalid photo upload'},400)}
   const file=form.get('photo');
   if(!file || typeof file==='string' || !file.type?.startsWith('image/'))return json({error:'Please upload an image'},400);
   if(file.size>10*1024*1024)return json({error:'Image exceeds 10 MB'},413);
   if(!['image/jpeg','image/png','image/webp','image/gif'].includes(file.type))return json({error:'Use JPEG, PNG, WebP or GIF'},415);
   const occasion=String(form.get('occasion')||'casual').slice(0,40);
   const bytes=new Uint8Array(await file.arrayBuffer());
   let binary=''; for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
   const b64=btoa(binary);
   const schema={type:'object',additionalProperties:false,properties:{findings:{type:'array',items:{type:'object',additionalProperties:false,properties:{area:{type:'string',enum:areas},observation:{type:'string'},suggestion:{type:'string'},professional:{type:'string'}},required:['area','observation','suggestion','professional']}}},required:['findings']};
   let ai;
   try{
    ai=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:env.OPENAI_MODEL||'gpt-4o-mini',temperature:0.3,max_tokens:1800,response_format:{type:'json_schema',json_schema:{name:'look_analysis',strict:true,schema}},messages:[{role:'system',content:SYSTEM},{role:'user',content:[{type:'text',text:`Review the visible appearance in this image for occasion: ${occasion}. Provide one finding for each of the nine listed areas. Give concrete actionable suggestions, but never invent invisible details.`},{type:'image_url',image_url:{url:`data:${file.type};base64,${b64}`,detail:'auto'}}]}]})});
   }catch{return json({error:'Could not reach AI service. Try again.'},502)}
   if(!ai.ok){const detail=await ai.json().catch(()=>({}));return json({error:ai.status===429?'AI service is busy or quota exceeded. Try again later.':`AI provider error (${ai.status}).`,detail:env.DEBUG_ERRORS==='true'?detail.error?.message:undefined},502)}
   const result=await ai.json();
   try{const parsed=JSON.parse(result.choices?.[0]?.message?.content||'{}');if(!Array.isArray(parsed.findings))throw Error();return json({findings:parsed.findings})}catch{return json({error:'AI returned an invalid result. Try another photo.'},502)}
  }
  return env.ASSETS.fetch(request);
 }
};
